﻿using Assessment.Models;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;



namespace Assessment.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        public HomeController(ILogger<HomeController> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()   
         {
            try
            {
                string sourceUrl = "https://www.cbc.ca/cmlink/rss-topstories";

                using (HttpClient httpClient = _httpClientFactory.CreateClient())
                {
                    // httpClient instance making HTTP requests
                    HttpResponseMessage response = await httpClient.GetAsync(sourceUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        string xmlContent = await response.Content.ReadAsStringAsync();
                        var fetchData = new FetchData();
                        List<FetchData> feedItems = fetchData.ParseXmlContent(xmlContent);

                        return View(feedItems);
                    }
                    else
                    {
                        // Handle error cases when the HTTP request fails
                        return RedirectToAction("HttpError", "Home", new { statusCode = (int)response.StatusCode });
                    
                    }
                }
            }
            catch (Exception) 
            {
                return RedirectToAction("Error");
            }
             
         }

        // Handle the specific status code as needed
        public IActionResult HttpError(int statusCode)
        {
            ViewBag.StatusCode = statusCode;
            return View("HttpError");
        }

        //Handle Global Exception/Error
        public IActionResult Error()
        {
            // Get the exception details from the HttpContext
            var exceptionHandlerPathFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            ViewBag.ErrorMessage = "An unexpected error occurred.";

            return View();
        }
    }
}
