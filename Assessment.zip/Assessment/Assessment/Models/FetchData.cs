﻿using System.Xml;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Assessment.Models
{
    public class FetchData
    {    
            public string Title { get; set; }
            public string Author { get; set; }
            public string Description { get; set; }
            public string ImageUrl { get; set; }

        public List<FetchData> ParseXmlContent(string xmlContent)
        {
            XDocument xmlDocument = XDocument.Parse(xmlContent);

            List<FetchData> ObjFeedData = new List<FetchData>();

            try
            {
                
                foreach (XElement item in xmlDocument.Descendants("item"))
                {
                    // In XML structure <description> have <p>, <image> tag which include src, image title, alt, width and height
                    // also there is some bad text in it like "&#39;" in the description.
                    // image title also contain text information which is part of description.
                    // Below code will extract and remove the information

                    string? description = item.Element("description")?.Value;

                    // Extract the title text and removing text &#39 which is inside <description> from the XML
                    string titleDescription = ExtractTitleFromDescription(description);

                    // Extract the image URL from the from the description
                    string imageUrl = ExtractImageUrlFromDescription(description);

                    //remove the <Image> and <p> from the Description
                    description = RemoveDataFromDescription(description);

                    //If Author data not available, assign Unknown
                    string? author = item.Element("author")?.Value;
                    if (string.IsNullOrWhiteSpace(author))
                    {
                        author = "Unknown";
                    }

                    FetchData FeedData = new FetchData
                    {
                        Title = item.Element("title")?.Value,
                        Author = author,
                        Description = titleDescription + description, //  Merge the title text of <description> with the description text
                        ImageUrl = imageUrl
                    };

                    ObjFeedData.Add(FeedData);
                }

                return ObjFeedData;
            }
            catch (Exception)
            {
                throw;
            }
        
        }
       
        //Extract image src from the Description
        private string ExtractImageUrlFromDescription(string description)
        {
            try
            {
                //Extracting the image URL from Description using HtmlAgilityPack
                HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                htmlDoc.LoadHtml(description);

                HtmlAgilityPack.HtmlNode imgNode = htmlDoc.DocumentNode.SelectSingleNode("//img");

                string imageUrl = imgNode?.GetAttributeValue("src", "");

                return imageUrl;
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        //Remove the image src and <p> tage text from Description information
        private string RemoveDataFromDescription(string description)
        {
            try
            {
                //removing image src and <p> tag from the description using HtmlAgilityPack
                HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                htmlDoc.LoadHtml(description);

                HtmlAgilityPack.HtmlNode imgNode = htmlDoc.DocumentNode.SelectSingleNode("//img");
                HtmlAgilityPack.HtmlNodeCollection pNodeCollection = htmlDoc.DocumentNode.SelectNodes("//p");


                if (imgNode != null)
                {
                    // Remove the img node from the Description
                    imgNode.Remove();
                }

                if (pNodeCollection != null)
                {
                    //remove the <p> from the Description
                    foreach (var pNode in pNodeCollection)
                    {
                        pNode.ParentNode.RemoveChild(pNode, true);
                    }
                }

                string cleanedDescription = htmlDoc.DocumentNode.InnerHtml;

                return cleanedDescription;
            }
            catch (Exception)
            {
                throw;
            }          
        }

        //Extract data in title from the <description>
        private string ExtractTitleFromDescription(string description)
        {
            const string titleStartTag = "title='";
            const string titleEndTag = "'";

            int startIndex = description.IndexOf(titleStartTag) + titleStartTag.Length;
            int endIndex = description.IndexOf(titleEndTag, startIndex);

            if (startIndex >= 0 && endIndex >= 0)
            {
                string title = description.Substring(startIndex, endIndex - startIndex);

                //Here also removing text and special character "&#39;" as this was inside title tag
                string finalTitle = WebUtility.HtmlDecode(title);
                finalTitle = finalTitle.Replace("&#39;", string.Empty);
                return finalTitle;
            }
            

            return string.Empty;
        }

    }
}
